# -*- coding: utf-8 -*-
"""
Created on Wed Feb 14 11:33:58 2018

@author: Ruslan Safiullin
"""




#%% Ex1

import zipfile
import numpy as np
import pandas as pd
import requests
import urllib.request


url = 'https://drive.google.com/uc?export=download&id=0B6ZlG_Eygdj-c1kzcmUxN05VUXM'
path = 'developer_survey_2017'

response = requests.get(url)
with open(path, "wb") as file:
    file.write(response.content)
    
    
zf = zipfile.ZipFile(path)
files = zf.namelist()

print(files)

public = pd.read_csv(zf.open(files[-2]))
schema = pd.read_csv(zf.open(files[-1]))
public.columns = [x.strip() for x in public.columns]
schema.cmns = [x.strip() for x in schema.columns]


schema.head() 

#%%##
public.iloc[:,:2].head()
#%% Ex2
data1 = public['Country'].value_counts() 

public1d = pd.Series.to_frame(data1)
public1d.rename(columns={'Country':'Frequency'}, inplace = True)
public1d.head(10)
#%%
public2 = public['Country'].value_counts()/len(public['Country'])
public2.head(10)
#%%  Ex3  Something went wrong here

resp = urllib.request.urlopen('https://en.wikipedia.org/wiki/List_of_countries_and_dependencies_by_population')
html = resp.read()

url = 'https://en.wikipedia.org/wiki/List_of_countries_and_dependencies_by_population' 
r = requests.get(url)
with open('test.html', 'w') as output_file:
  output_file.write(r.text)
  
#%%  Ex4

# Максимальные совпадения по столбцу делаем groupby & sort values by descending
d = public
da = d[['Respondent', 'VersionControl']].groupby(['VersionControl']).count()
da2 = da.sort_values(by=['Respondent'],ascending = False)
da2[:10]



#%%  Ex5

public['HaveWorkedLanguage'].head()
#defining new list
languages = []
lister = public['HaveWorkedLanguage'].dropna() 
#create double cysle to append all data
for i in lister:
    datas = i.split(';') #чистка данных
    for k in datas:
        k = k.replace(' ','')
        if languages.count(k) == 0:
            languages.append(k) #adding to the end of list
            
print(languages)

#%%  Ex6
##the same thing as in exercise 5, although we create a counter 
languages_2 = pd.Series(0, index = languages)
for i in lister:
    datas = i.split(';')
    for k in datas:
        k = k.replace(' ','')
        languages_2[k] += 1 ##counter

languages_2 = languages_2.sort_values(ascending = False)
languages_2.head(10)



