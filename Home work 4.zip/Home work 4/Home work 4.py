# -*- coding: utf-8 -*-
"""
Created on Mon Feb 12 11:09:41 2018

@author: User
"""
#%%
from collections import Counter
import numpy as np
import pandas as pd
import scipy.stats as scs
import matplotlib.pylab as plt
import seaborn as sns
import re

#%%

#Task 1

data = pd.read_csv("survey_results_public.csv")
schema = pd.read_csv("survey_results_schema.csv")
print(data.iloc[:,:2].head())

print(schema.head())


#%% 

#Task 2
#np.set_printoptions(precision=6, suppress=True)

counts = data.copy()
counts = counts.groupby(['Country']).count()

print(counts.iloc[:,:1].sort_values(['Respondent'], ascending = False).head(10))

pd.options.display.float_format = '{:,.6f}'.format
counts2 = counts.iloc[:,:1].sort_values(['Respondent'], ascending = False)

print(counts2.iloc[:, :1].head(10) / data['Respondent'].count())

#%%

#Task 3
# подготовка датафрейма

data3 = counts2
data3['Ratio'] = counts2.iloc[:, :1] / data['Respondent'].count()
data3['Respondent'] =  counts.iloc[:,:1].sort_values(['Respondent'], ascending = False)

#%%
#import requests
#from bs4 import BeautifulSoup

WIKI_URL = "https://en.wikipedia.org/wiki/List_of_countries_and_dependencies_by_population"

Wikitable = pd.read_html(WIKI_URL)
Wikitable = Wikitable[1]

Countries = []
Population = []

for i in Wikitable[1]:
#    print (i)
    k = i
    i = re.sub(r"[Note [0-9]+]", "", i)
    i = re.sub(r'\(.+\)', "", i)
    Countries.append(i)

for i in Wikitable[2]:
    if i != 'Population':
        
        Population.append(int(i))
    else:
        Population.append(i)
    
Countries.pop(0)
Population.pop(0)

Data = pd.DataFrame({'Country_': Countries, 'Population': Population}, index = None)

respondents = data['Country'].value_counts()
respondents_frame = pd.DataFrame({'Country_': respondents.index, 'Country': pd.to_numeric(respondents.values)}, index = None)

Final_data = pd.merge(Data, respondents_frame, on='Country_', how='inner')
Final_data = Final_data[Final_data['Country'] >= 100]

Final_data['Ratio'] = Final_data['Country'] / Final_data['Population']
Final_data = Final_data.sort_values(by = ['Ratio'], ascending = False)

Final_data.head(10)

#%%

# Task 4

counts = data.copy()
counts = counts.groupby(['VersionControl']).count()

print(counts.iloc[:,:1].sort_values(['Respondent'], ascending = False).head(10))

#%%

# Task 5

languages = [] 

for new_lang in data['HaveWorkedLanguage'].dropna():
    set_lang = new_lang.split(';')
    
    for lang in set_lang:
        lang = re.sub(r' ', '', lang)
        
        if lang not in languages:
            languages.append(lang)
            
print(languages)

#%%

# Task 6

series = pd.Series(0, index = languages)
#Создадим Series, в которой будем для каждого языка суммировать количество относящихся респондентов


for new_lang in data['HaveWorkedLanguage'].dropna():
    set_lang = new_lang.split(';')
    
    for lang in set_lang:
        lang = re.sub(r' ', '', lang)
        series[lang] = series[lang] + 1

series = series.sort_values(ascending = False)
series.head(10)

#%%

# Task 7

#data['HaveWorkedLanguage']

counts = data.copy()
counts = counts.groupby(['Country']).count()

data_frame = counts.iloc[:,:1].sort_values(['Respondent'], ascending = False)
data_frame

Country_lang = {}

for i in data['Respondent']:
    Country = data['Country'].iloc[i - 1]
    if Country in Country_lang:
        for new_lang in data['HaveWorkedLanguage'].iloc[i - 1]:
            set_lang = new_lang.split(';')
            for lang in set_lang:
                lang = re.sub(r' ', '', lang)
                print(Country)
                Country_lang[Country].append(lang)
#    else:
#        set_lang = data['HaveWorkedLanguage'].iloc[i - 1].split(';')
#        for lang in set_lang:
#            lang = re.sub(r' ', '', lang)
#            Country_lang[Country] = lang

Country_lang
#%%
import math

def isnan(value): 
    try: 
        return math.isnan(float(value)) 
    except: 
        return False

Languages = data['HaveWorkedLanguage'].get_values()
Countries = data['Country'].get_values()

Dict = dict.fromkeys(set(Countries))

for country in Dict:
    Dict[country] = list()


for country, language in zip(Countries, Languages):
    if isnan(language) == True:
        continue
    set_language = language.split(';')
    set_language = list(map(lambda s: s.replace(' ',''), set_language))
    for lang in set_language:
#        if country in Dict:
#            Dict[country].append(lang)
#        else:
#            Dict[country] = [lang]
#        print(lang)
#        print(country)
        Dict[country].append(lang)


language = pd.Series(str(), index = Dict.keys())

Dict.keys()

#language['Country'] = Dict.keys()
#language

for country in Dict.keys():
    c = Counter(Dict[country])
#    print(c)
    lin = c.most_common(1)
    if len(lin) != 0:
        language[country] = lin[0][0]

language = language.sort_values(ascending = False)
language['India']

Country = data['Country'].value_counts()
Country['India']

data_frame = pd.DataFrame({'Country_': Country.index, 'Total': Country.values}, index = None)
result_language_frame = pd.DataFrame({'Country_': language.index, 'Popular': language.values}, index = None)
Data_frame = pd.merge(data_frame, result_language_frame, on='Country_', how='inner')

Data_frame.head(10)
#%%
N = Data_frame[Data_frame['Popular'] != 'JavaScript']
N.head(5)